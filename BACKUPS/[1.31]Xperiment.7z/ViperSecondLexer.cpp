using namespace std;
#include "Viper.tab.h"
#include "string.h"
#include "iostream"
#include "fstream"
const int SIZE = 4096;
class Token {
public:
	int lineno;
	int type;
	int availability;
	union {
		double D;
		int I;
		char * S;
		char C;
	} value;
	Token(){
		availability = 0;
		lineno = 0;
		type = 0;
		value.D = 0;
		value.C = 0;
		value.S = 0;
		value.I = 0;
	};
};
int yylex(Token * t, int i);
int ReadTokens(ifstream &f, Token * t);
void DispTokens(Token * t);
int main(int argc, char * argv[]){
	ofstream fout;
	if (argc != 2) {
		fprintf(stderr, "1 argument required!");
		exit(1);
	}
	ifstream fin(argv[1], ios::in);
	if (fin.fail() || fin.bad()) {
		fprintf(stderr, "Destination Error");
		exit(1);
	}
	Token * T = new Token[SIZE];
	ReadTokens(fin, T);
	DispTokens(T);
	return yyparse();
};
void DispTokens(Token * t) {
	system("CLS");
	for (int i = 0; i < SIZE && t[i].availability != 0; i++) {
		cout << t[i].lineno << "\t" << t[i].type << "\t";
		switch (t[i].type) {
			case STRING:{
				cout << t[i].value.S;
				break;
			}
			case NUMBER:{
				cout << t[i].value.D;
				break;
			}
			case CHAR:{
				cout << t[i].value.C;
				break;
			}
			case NAME:{
				cout << t[i].value.S;
				break;
			}
			default:{
				cout << t[i].value.S;
				break;
			}
		}
		cout << endl;
	}
};
int ReadTokens(ifstream &f, Token * t) {
	for (int i = 0; i < SIZE; i++) {
		if (f.eof()){
			cout << "EOF" << endl;
			break;
		}
		f >> t[i].lineno;
		f >> t[i].type;
		//cout << "Switch" << endl;
		switch (t[i].type) {
			case STRING:{
				cout << "STRING" << endl;
				char temp;
				f.get(temp);
				//f.seekg(1, ios::cur);
				t[i].value.S = new char[1024];
				f.getline(t[i].value.S, 1024);
				break;
			}
			case NUMBER:{
				cout << "NUMBER" << endl;
				f >> t[i].value.D;
				break;
			}
			case CHAR:{
				cout << "CHAR" << endl;
				f >> t[i].value.C;
				break;
			}
			case NAME:{
				cout << "NAME" << endl;
				t[i].value.S = new char[1024];
				f >> t[i].value.S;
				break;
			}
			default:{
				//cout << "DEFAULT" << endl;
				t[i].value.S = new char[1024];
				f >> t[i].value.S;
				break;
			}
		}
		if (!f.eof()){
			t[i].availability = 1;
		}
	}
	f.close();
	return 0;
};
int yylex(Token * t, int i){
	//yywtfval = t[i].value? switch with the type!
	return t[i].type;
}
